# Parallax Scrolling Website(视差滚动网站)

视频中用到的图片：（clone 代码里面就有，如果不想 clone 可以去网盘自取）
https://pan.baidu.com/s/1nPdUz1lPUQhZ2E53R6mEsQ
提取码：
u7wm

